# Testing report

## Execution status

No Android SDK, Android emulator, Gradle or JDK 17 was available in the authoring environment. Consequently this project was not compiled, installed, run on a device, or tested on Android API levels. No APK is included. Source is provided as an unverified implementation, not a verified production release. Dependency retrieval, compilation, usability and security require validation in an Android development environment.

## Suggested validation (not performed)

- Build using the README commands, install using adb on API 26 and API 35 devices/emulators.
- First-run: configure a date and PIN; verify mismatched confirmation and invalid lengths fail. Verify app restart preserves settings.
- Navigate across month/year boundaries including February 2024 and 2025, verify weekdays/today, non-secret selection, exact secret-date activation and no activation for other dates.
- Enter wrong PIN repeatedly, test delay across restart; check correct PIN opens vault after delay. Check foreground/background locking including while verification is running.
- Add, search, launch, and remove apps; uninstall a chosen app and ensure vault remains usable. Test launch errors.
- Change PIN, date, and theme; verify they persist and old credentials no longer work. Check light/dark, small and large screens, scaling and accessibility.
- Simulate corrupt encrypted state and failed writes, unavailable Keystore, clock changes, process death during writes, and restore/reinstall.
- Inspect APK manifest and audit dependencies and cryptographic behavior before deployment.
