# ChronoVault Android project

Native Kotlin / Jetpack Compose Android project. API 26 minimum, compile/target API 35. No internet permission, advertising SDK, or analytics. Private shortcuts do not hide installed apps. The secret is a **full date**, not a repeating day of month. On first launch choose a date and a 4- or 6-digit PIN, then navigate to the exact month and tap that date. Vault locks when the activity stops. Changing the PIN/date requires access to the unlocked vault.

## Build prerequisites

Android Studio with Android SDK Platform 35 and SDK Build Tools, JDK 17 and Gradle 8.9; internet access for dependency resolution. Open this folder as a project and sync Gradle. Alternatively install Gradle 8.9 and set ANDROID_HOME to your SDK location, then run from this directory:

```sh
gradle --version
gradle :app:assembleDebug
```

The APK is `app/build/outputs/apk/debug/app-debug.apk`. Copy it to `ChronoVault-debug.apk` if desired. This project does not include a Gradle wrapper; one can be generated using `gradle wrapper --gradle-version 8.9`, then use `./gradlew :app:assembleDebug`.

## Installation

Transfer the debug APK to a device on Android 8.0 or later, permit installation from your file manager if prompted, and open it. Or enable USB debugging and use `adb install -r app/build/outputs/apk/debug/app-debug.apk`. Debug builds are signed with the local debug key and are not suitable for production distribution.

## Release signing

Create a private signing key and keep it and its passwords safe:

```sh
keytool -genkeypair -v -keystore chronovault-release.jks -alias chronovault -keyalg RSA -keysize 3072 -validity 10000
gradle :app:assembleRelease
$ANDROID_HOME/build-tools/35.0.0/zipalign -p -f 4 app/build/outputs/apk/release/app-release-unsigned.apk chronovault-aligned.apk
$ANDROID_HOME/build-tools/35.0.0/apksigner sign --ks chronovault-release.jks --ks-key-alias chronovault --out ChronoVault-release.apk chronovault-aligned.apk
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose ChronoVault-release.apk
```

Use the installed SDK build-tools version if different. Never commit the keystore or passwords. Losing the signing key can prevent updates.

## Security limitations

State is encrypted with AES-GCM using an Android Keystore key; the PIN verifier uses salted PBKDF2-HMAC-SHA256 (210,000 iterations). Failed attempts are stored with exponential time-based delays; changing device time or rolling back device storage can undermine them. Four-digit PINs are intrinsically low entropy. Data and key do not survive uninstall; backup is disabled. A rooted/compromised device or someone who can use an unlocked vault is outside the protection boundary. Screenshots are not blocked. No PIN recovery is provided. This implementation has not received an independent security review and must not be treated as a high-security storage product.

See TESTING.md for the actual test status and suggested manual checks.
