package com.chronovault.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore("chronovault")
class SecureStore(private val context: Context) {
    private val key = stringPreferencesKey("encrypted_state")
    private fun secret(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("chronovault_key", null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder("chronovault_key", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun un64(s: String) = Base64.decode(s, Base64.NO_WRAP)
    suspend fun load(): JSONObject? {
        val encoded = context.dataStore.data.first()[key] ?: return null
        val all = un64(encoded); require(all.size > 28)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        return JSONObject(String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8))
    }
    suspend fun save(state: JSONObject) {
        val c = Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE, secret())
        val encoded = b64(c.iv + c.doFinal(state.toString().toByteArray(Charsets.UTF_8)))
        context.dataStore.edit { it[key] = encoded }
    }
    fun setPin(state: JSONObject, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        state.put("salt", b64(salt)); state.put("hash", b64(derive(pin, salt)))
    }
    fun verify(state: JSONObject, pin: String): Boolean = MessageDigest.isEqual(un64(state.getString("hash")), derive(pin, un64(state.getString("salt"))))
    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 210000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded } finally { spec.clearPassword() }
    }
}
