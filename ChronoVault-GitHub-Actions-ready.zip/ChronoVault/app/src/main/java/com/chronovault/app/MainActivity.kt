package com.chronovault.app

import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChronoApp() }
    }
}

@Composable fun ChronoApp() {
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    val scope = rememberCoroutineScope()
    val store = remember { SecureStore(ctx) }
    var state by remember { mutableStateOf<JSONObject?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("calendar") }
    var pin by remember { mutableStateOf("") }
    var firstPin by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf(LocalDate.now()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var revision by remember { mutableIntStateOf(0) }
    var authGeneration by remember { mutableIntStateOf(0) }
    val saveMutex = remember { Mutex() }
    fun persist(s: JSONObject) { revision++; val snapshot = JSONObject(s.toString()); scope.launch { try { saveMutex.withLock { store.save(snapshot) } } catch (e: Exception) { error = "Unable to save secure data: ${e.localizedMessage}" } } }
    fun lock() { authGeneration++; screen = "calendar"; pin = ""; firstPin = ""; mode = "" }
    LaunchedEffect(Unit) {
        try { state = store.load(); if (state == null) screen = "setupDate" }
        catch (e: Exception) { error = "Secure data could not be read. Reinstalling clears all vault data. ${e.localizedMessage}"; screen = "fatal" }
        loaded = true
    }
    DisposableEffect(activity) {
        val observer = object : DefaultLifecycleObserver { override fun onStop(owner: LifecycleOwner) { if (state != null) lock() } }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }
    val s = state
    val theme = revision.let { s?.optString("theme", "System") ?: "System" }
    val dark = theme == "Dark" || (theme == "System" && isSystemInDarkTheme())
    MaterialTheme(colorScheme = if (dark || screen in listOf("vault", "settings", "apps")) darkColorScheme(primary = Color(0xFFB6B5FF)) else lightColorScheme(primary = Color(0xFF4945A5))) {
        Surface(Modifier.fillMaxSize()) {
            if (!loaded) return@Surface
            if (screen != "calendar" && screen != "setupDate" && screen != "fatal") BackHandler { if (screen == "vault" || screen == "auth") lock() else if (screen == "setupPin") screen = "setupDate" else screen = "vault" }
            Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp)) {
                if (error.isNotEmpty()) { Text(error, color = MaterialTheme.colorScheme.error); TextButton(onClick = { error = "" }) { Text("Dismiss") } }
                when (screen) {
                    "fatal" -> Text("Secure storage unavailable. No data has been reset automatically.")
                    "setupDate", "changeDate" -> {
                        val setup = screen == "setupDate"
                        DateEntry(if (setup) "Choose your secret date" else "Change secret date", selected) { date ->
                            selected = date
                            if (setup) { screen = "setupPin"; mode = "new"; pin = ""; firstPin = "" }
                            else if (s != null) { s.put("date", date.toString()); persist(s); screen = "settings" }
                        }
                    }
                    "calendar" -> {
                        Text("ChronoVault", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹", style = MaterialTheme.typography.headlineMedium) }
                            AnimatedContent(month, label = "month") { m -> Text(m.format(DateTimeFormatter.ofPattern("MMMM yyyy")), style = MaterialTheme.typography.titleLarge) }
                            TextButton(onClick = { month = month.plusMonths(1) }) { Text("›", style = MaterialTheme.typography.headlineMedium) }
                        }
                        Row(Modifier.fillMaxWidth()) { (1..7).forEach { Text(java.time.DayOfWeek.of(it).getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(2), Modifier.weight(1f), style = MaterialTheme.typography.labelMedium) } }
                        val offset = month.atDay(1).dayOfWeek.value - 1
                        val cells = (offset + month.lengthOfMonth() + 6) / 7 * 7
                        repeat(cells / 7) { row -> Row(Modifier.fillMaxWidth()) { repeat(7) { col ->
                            val day = row * 7 + col - offset + 1
                            if (day in 1..month.lengthOfMonth()) {
                                val date = month.atDay(day)
                                val today = date == LocalDate.now()
                                Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp).background(if (today) MaterialTheme.colorScheme.primaryContainer else Color.Transparent, RoundedCornerShape(50)).clickable {
                                    selected = date
                                    if (s != null && date.toString() == s.optString("date")) { pin = ""; screen = "auth" }
                                }, contentAlignment = Alignment.Center) { Text("$day", fontWeight = if (today) FontWeight.Bold else FontWeight.Normal) }
                            } else Spacer(Modifier.weight(1f).aspectRatio(1f))
                        } } }
                        Spacer(Modifier.height(28.dp)); Text("Selected", style = MaterialTheme.typography.labelLarge)
                        Text(selected.format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy")), style = MaterialTheme.typography.titleMedium)
                    }
                    "setupPin", "auth", "changePin" -> {
                        val setup = screen == "setupPin"; val change = screen == "changePin"
                        val title = if (screen == "auth") "Enter your PIN" else if (firstPin.isEmpty()) "Choose a 4 or 6 digit PIN" else "Confirm your PIN"
                        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(24.dp)); Text("●".repeat(pin.length).ifEmpty { "Enter PIN" }, style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(16.dp))
                        listOf(listOf("1","2","3"), listOf("4","5","6"), listOf("7","8","9"), listOf("Clear","0","⌫")).forEach { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { line.forEach { n -> TextButton(onClick = { pin = when(n) { "Clear" -> ""; "⌫" -> pin.dropLast(1); else -> if (pin.length < 6) pin+n else pin } }, modifier = Modifier.size(80.dp, 64.dp)) { Text(n, style = MaterialTheme.typography.titleLarge) } } }
                        }
                        Button(onClick = {
                            if (pin.length != 4 && pin.length != 6) { error = "Enter a 4 or 6 digit PIN."; return@Button }
                            if (screen == "auth" && s != null) {
                                val now = System.currentTimeMillis(); val until = s.optLong("blockedUntil", 0L)
                                if (now < until) { error = "Too many attempts. Try again in ${(until-now+999)/1000} seconds."; pin = ""; return@Button }
                                scope.launch {
                                    val candidate = pin; val generation = authGeneration; pin = ""
                                    try {
                                        val ok = withContext(Dispatchers.Default) { store.verify(s, candidate) }
                                        if (ok) { s.put("attempts", 0); s.put("blockedUntil", 0L); persist(s); if (generation == authGeneration && screen == "auth") screen = "vault" }
                                        else { val count = s.optInt("attempts") + 1; s.put("attempts", count); if (count >= 5) s.put("blockedUntil", System.currentTimeMillis() + minOf(3600L, 30L * (1L shl minOf(count - 5, 7))) * 1000); persist(s); error = "Incorrect PIN." }
                                    } catch (e: Exception) { error = "Unable to verify PIN: ${e.localizedMessage}" }
                                }
                            } else if (firstPin.isEmpty()) { firstPin = pin; pin = "" }
                            else if (firstPin != pin) { firstPin = ""; pin = ""; error = "PINs do not match. Try again." }
                            else {
                                val candidate = pin; pin = ""; firstPin = ""
                                scope.launch {
                                    try { val obj = s ?: JSONObject().put("date", selected.toString()).put("apps", JSONArray()).put("theme", "System")
                                        withContext(Dispatchers.Default) { store.setPin(obj, candidate) }; state = obj; persist(obj); screen = if (setup) "calendar" else "settings"
                                    } catch (e: Exception) { error = "Could not save PIN: ${e.localizedMessage}" }
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
                        if (!setup) TextButton(onClick = { if (change) screen = "settings" else lock() }) { Text("Cancel") }
                    }
                    "vault" -> {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Private Vault", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); TextButton(onClick = { lock() }) { Text("Lock") } }
                        Text("Your private shortcuts", style = MaterialTheme.typography.bodyMedium)
                        Row { TextButton(onClick = { screen = "apps" }) { Text("Manage apps") }; TextButton(onClick = { screen = "settings" }) { Text("Settings") } }
                        var query by remember { mutableStateOf("") }
                        OutlinedTextField(query, { query = it }, label = { Text("Search shortcuts") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        val packages = revision.let { jsonApps(s) }
                        val apps = remember(revision) { launchable(ctx).filter { packages.contains(it.activityInfo.packageName) } }
                        val filtered = apps.filter { it.loadLabel(ctx.packageManager).toString().contains(query, true) }
                        if (filtered.isEmpty()) Text(if (packages.isEmpty()) "No shortcuts yet. Select Manage apps to add some." else "No available shortcuts match your search.", Modifier.padding(vertical = 24.dp))
                        LazyVerticalGrid(columns = GridCells.Adaptive(100.dp)) { items(filtered.size) { i -> AppTile(filtered[i], onClick = {
                            try { val a = filtered[i].activityInfo; ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(a.packageName, a.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { error = "Unable to launch app: ${e.localizedMessage}" }
                        }) } }
                    }
                    "apps" -> {
                        Text("Manage shortcuts", style = MaterialTheme.typography.headlineSmall)
                        Text("Only launchable apps visible to Android are listed.")
                        var query by remember { mutableStateOf("") }
                        OutlinedTextField(query, { query = it }, label = { Text("Search apps") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        val apps = remember { launchable(ctx) }.filter { it.loadLabel(ctx.packageManager).toString().contains(query, true) }
                        val chosen = revision.let { jsonApps(s) }
                        androidx.compose.foundation.lazy.LazyColumn { items(apps.size) { i -> val app = apps[i]; val pkg = app.activityInfo.packageName
                            Row(Modifier.fillMaxWidth().clickable { if (s != null) { val updated = chosen.toMutableSet(); if (!updated.add(pkg)) updated.remove(pkg); s.put("apps", JSONArray(updated.toList())); persist(s) } }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                val bitmap = remember(pkg) { runCatching { app.loadIcon(ctx.packageManager).toBitmap(96,96).asImageBitmap() }.getOrNull() }; if (bitmap != null) Image(bitmap, null, Modifier.size(40.dp))
                                Text(app.loadLabel(ctx.packageManager).toString(), Modifier.weight(1f).padding(start = 12.dp)); Checkbox(checked = pkg in chosen, onCheckedChange = { checked -> if (s != null) { val updated = chosen.toMutableSet(); if (checked) updated.add(pkg) else updated.remove(pkg); s.put("apps", JSONArray(updated.toList())); persist(s) } })
                            }
                        } }
                    }
                    "settings" -> {
                        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { pin = ""; firstPin = ""; screen = "changePin" }) { Text("Change PIN") }
                        TextButton(onClick = { selected = runCatching { LocalDate.parse(s?.getString("date")) }.getOrDefault(LocalDate.now()); screen = "changeDate" }) { Text("Change secret date") }
                        TextButton(onClick = { screen = "apps" }) { Text("Manage shortcuts") }
                        Text("Theme", style = MaterialTheme.typography.titleMedium)
                        Row { listOf("System", "Light", "Dark").forEach { t -> TextButton(onClick = { s?.put("theme", t); if (s != null) persist(s) }) { Text(if (theme == t) "✓ $t" else t) } } }
                        Text("Security", style = MaterialTheme.typography.titleMedium)
                        Text("Vault locks when the app leaves the foreground. Failed PIN attempts trigger increasing delays. The secret date is a full calendar date.")
                        Spacer(Modifier.height(12.dp)); Text("About & privacy", style = MaterialTheme.typography.titleMedium)
                        Text("ChronoVault stores encrypted data on this device. No accounts, ads, analytics or network access. Shortcuts do not hide apps from Android or other launchers.")
                        TextButton(onClick = { lock() }) { Text("Return to calendar and lock") }
                    }
                }
            }
        }
    }
}

@Composable fun DateEntry(title: String, initial: LocalDate, done: (LocalDate) -> Unit) {
    var input by remember { mutableStateOf(initial.toString()) }; var invalid by remember { mutableStateOf(false) }
    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp)); Text("Enter a full date (YYYY-MM-DD). Remember it: selecting this date opens authentication.")
    OutlinedTextField(input, { input = it; invalid = false }, label = { Text("Secret date") }, isError = invalid, singleLine = true, modifier = Modifier.fillMaxWidth())
    if (invalid) Text("Enter a valid date, for example 2026-11-12.", color = MaterialTheme.colorScheme.error)
    Button(onClick = { val d = runCatching { LocalDate.parse(input) }.getOrNull(); if (d == null) invalid = true else done(d) }, modifier = Modifier.padding(top = 16.dp)) { Text("Continue") }
}
fun jsonApps(s: JSONObject?): Set<String> { val a = s?.optJSONArray("apps") ?: return emptySet(); return (0 until a.length()).map { a.optString(it) }.toSet() }
fun launchable(ctx: android.content.Context): List<ResolveInfo> = ctx.packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0).filter { it.activityInfo.packageName != ctx.packageName }.distinctBy { it.activityInfo.packageName }.sortedBy { it.loadLabel(ctx.packageManager).toString().lowercase() }
@Composable fun AppTile(app: ResolveInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.padding(8.dp).clickable(onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        val bitmap = remember(app) { runCatching { app.loadIcon(ctx.packageManager).toBitmap(128,128).asImageBitmap() }.getOrNull() }
        if (bitmap != null) Image(bitmap, null, Modifier.size(56.dp)) else Spacer(Modifier.size(56.dp))
        Text(app.loadLabel(ctx.packageManager).toString(), maxLines = 2, style = MaterialTheme.typography.labelMedium)
    }
}
